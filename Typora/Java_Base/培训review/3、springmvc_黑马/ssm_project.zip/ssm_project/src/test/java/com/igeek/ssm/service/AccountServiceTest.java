package com.igeek.ssm.service;

import com.igeek.ssm.service.impl.AccountServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AccountServiceTest {
    @Autowired
    private AccountServiceImpl accountService;

    public void setAccountService(AccountServiceImpl accountService) {
        this.accountService = accountService;
    }
    @Before
    public void init(){
        ApplicationContext ac = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
        accountService = (AccountServiceImpl) ac.getBean("accountService");
    }

    @Test
    public void findAllTest(){
        accountService.findAllAccounts();
    }
}
