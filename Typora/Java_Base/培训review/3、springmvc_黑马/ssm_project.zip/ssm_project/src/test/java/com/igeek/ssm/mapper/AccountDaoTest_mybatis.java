package com.igeek.ssm.mapper;

import com.igeek.ssm.domain.Account;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class AccountDaoTest_mybatis {
    private AccountDao accountDao;
    private InputStream in = null;
    private SqlSession sqlSession = null;

    @Before
    public void init() throws Exception {
        System.out.println("进入AccountDaoTest_mybatis.init().............");
        //加载配置文件
        in = Resources.getResourceAsStream("mybatis/sqlMapConfig.xml");
        //创建sqlSessionFactory对象
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
        //获取SqlSession对象
        sqlSession = sqlSessionFactory.openSession();
    }


    @Test
    public void testSelectAll(){
        System.out.println("进入AccountDaoTest_mybatis.testSelectAll().............");
        accountDao = sqlSession.getMapper(AccountDao.class);
        List<Account> accountList = accountDao.selectAll();
        for(Account account:accountList){
            System.out.println(account);
        }
    }

    @After
    public void after() throws IOException {
        System.out.println("进入AccountDaoTest_mybatis.after().............");
        //提交事务
        sqlSession.commit();
        //关闭资源
        sqlSession.close();
        in.close();

    }

    @Test
    public void testSaveAccount(){
        System.out.println("进入AccountDaoTest_mybatis.testSaveAccount().............");
        accountDao = sqlSession.getMapper(AccountDao.class);
        Account account = new Account();
        account.setId(3);
        account.setName("Rose");
        account.setMoney(2000d);
        accountDao.saveAccount(account);
        testSelectAll();
    }
}
