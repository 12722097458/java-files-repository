package com.igeek.ssm.service.impl;

import com.igeek.ssm.domain.Account;
import com.igeek.ssm.mapper.AccountDao;
import com.igeek.ssm.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service(value = "accountService")
public class AccountServiceImpl implements AccountService {
    @Autowired
    private AccountDao accountDao;

    @Override
    public List<Account> findAllAccounts() {
        System.out.println("进入了AccountServiceImpl.findAllAccounts()......");

        return accountDao.selectAll();
    }

    @Override
    public void saveAccountInfo(Account account) {
        System.out.println("进入了AccountServiceImpl.saveAccountInfo()......");
        accountDao.saveAccount(account);
    }
}
