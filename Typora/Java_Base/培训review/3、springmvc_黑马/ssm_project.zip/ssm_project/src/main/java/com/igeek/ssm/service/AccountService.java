package com.igeek.ssm.service;

import com.igeek.ssm.domain.Account;

import java.util.List;

public interface AccountService {
    //获取所有账户信息
    public List<Account> findAllAccounts();

    //保存账户信息
    public void saveAccountInfo(Account account);
}
