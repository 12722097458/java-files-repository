package com.igeek.ssm.mapper;

import com.igeek.ssm.domain.Account;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AccountDao {

    @Select(value = "select * from account")
    public List<Account> selectAll();

    @Insert(value = "insert into account(id,name,money) values(#{id},#{name},#{money})")
    public void saveAccount(Account account);
}
