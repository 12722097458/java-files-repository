package com.igeek.shop.exception;

import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
* 异常处理器
* */
public class MySysExceptionResolver implements HandlerExceptionResolver {
    @Override
    public ModelAndView resolveException(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) {

        //获取异常对象
        ExceptionSchema myExceptionSchema = null;

        if (e instanceof ExceptionSchema) {
            myExceptionSchema = (ExceptionSchema)e;
        } else {
            myExceptionSchema = new ExceptionSchema("系统正在维护，想稍后进行操作！");
        }
        //创建modelandview对象
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("errorMsg",myExceptionSchema.getMessage());
        modelAndView.setViewName("error");
        return modelAndView;

    }
}
