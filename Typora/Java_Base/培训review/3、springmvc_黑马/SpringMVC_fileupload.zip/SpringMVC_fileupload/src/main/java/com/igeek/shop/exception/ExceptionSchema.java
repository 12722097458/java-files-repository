package com.igeek.shop.exception;

import java.io.Serializable;

public class ExceptionSchema extends Exception implements Serializable {

    //存储错误提示信息
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ExceptionSchema(String message) {
        this.message = message;
    }
}
