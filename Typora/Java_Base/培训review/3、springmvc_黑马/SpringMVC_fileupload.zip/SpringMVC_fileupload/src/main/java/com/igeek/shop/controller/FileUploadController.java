package com.igeek.shop.controller;

import com.igeek.shop.exception.ExceptionSchema;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Controller
@RequestMapping(path = "/user")
public class FileUploadController {
    /*
     * SpringMVC 跨服务器文件上传方法   即开两个服务器（2个tomcat端口不同，同时启动）。
     * 一个服务器是文件服务器，不需要别的功能，接收存放文件就行。9999
     * 另一个服务器进行文件上传。
     * */
    @RequestMapping(path = "/fileUploadTest03")
    public String fileUploadTest03(HttpServletRequest request, MultipartFile file03) throws IOException {   //file02 必须和页面上的上名字一致   sprigMVC文件上传：<input type="file" name="file02">
        System.out.println("FileUploadController.fileUploadTest03()........");

        // 获取服务器存放文件路径
        String path = "http://localhost:9999/fileServer/uploads/";    //http://localhost:9999/fileServer  放入了浏览器可以访问到项目。/uploads/是存放文件的文件夹。target目录下一定要有不然409错误

        String uploadFileName = file03.getOriginalFilename();
        // 获取文件内容

        //重命名
        String newFileName = UUID.randomUUID().toString();

        int lastIndexOfDot = uploadFileName.lastIndexOf(".");
        if (lastIndexOfDot != -1) {
            // 有后缀,则要得到后缀
            String subfix = uploadFileName.substring(lastIndexOfDot);
            newFileName = newFileName + subfix;
        }

        //上传文件  跨服务器上传文件
        //创建客户端
        Client client = Client.create();
        //和服务器进行连接
        WebResource resource = client.resource(path + newFileName);
        //上传文件
        resource.put(file03.getBytes());    //通过字节传过去

        System.out.println("跨服务器文件上传成功！！！");
        return "success";
    }
    /*
    * SpringMVC方法
    * */
    @RequestMapping(path = "/fileUploadTest02")
    public String fileUploadTest02(HttpServletRequest request, MultipartFile file02) throws IOException {   //file02 必须和页面上的上名字一致   sprigMVC文件上传：<input type="file" name="file02">
        System.out.println("FileUploadController.fileUploadTest02()........");

        // 获取服务器存放文件路径
        String path = request.getSession().getServletContext().getRealPath("/file02_mvc/");
        File uploadFile = new File(path);
        if (!uploadFile.exists()) {
            uploadFile.mkdirs();
        }
        String uploadFileName = file02.getOriginalFilename();
        // 获取文件内容

        //重命名
        String newFileName = UUID.randomUUID().toString();

        int lastIndexOfDot = uploadFileName.lastIndexOf(".");
        if (lastIndexOfDot != -1) {
            // 有后缀,则要得到后缀
            String subfix = uploadFileName.substring(lastIndexOfDot);
            newFileName = newFileName + subfix;
        }

        //上传文件
        file02.transferTo(new File(path,newFileName));
        System.out.println("文件上传成功！！！");
        return "success";
    }


    /*
    * 传统方法
    * */
    @RequestMapping(path = "/fileUploadTest01")
    public String fileUploadTest01(HttpServletRequest request){
        System.out.println("FileUploadController.fileUploadTest01()........");

        // 为了有针对性的获取表单中其他普通控件值
        Map<String, String> params = new HashMap<String, String>();

        // 1.创建磁盘文件项工厂
        DiskFileItemFactory factory = new DiskFileItemFactory();
        // 第一个参数：缓存区大小 以字节为单位 第二个参数：缓存区的地址           上传的位置
        String temp_path = request.getSession().getServletContext().getRealPath("/fileiploads/");

        // DiskFileItemFactory factory = new DiskFileItemFactory(1024*1024,new
        // File(temp_path));
        File tempFile = new File(temp_path);
        if (!tempFile.exists()) {
            tempFile.mkdirs();
        }

        // 获取服务器存放文件路径
        String path = request.getSession().getServletContext().getRealPath("/file01/");

        File uploadFile = new File(path);
        if (!uploadFile.exists()) {
            uploadFile.mkdirs();
        }

        // 分别设置缓存区大小
        factory.setSizeThreshold(1024 * 1024);// 1M
        // 设置缓存的地址
        factory.setRepository(tempFile);

        // 2.创建核心类
        ServletFileUpload upload = new ServletFileUpload(factory);
        // 将上传文件名进行编码
        upload.setHeaderEncoding("UTF-8");

        // 判断表单的内容是不是文件上传 true---是文件上传 false---普通表单
        boolean multipartContent = ServletFileUpload.isMultipartContent(request);
        if (multipartContent) {
            // 文件上传
            try {
                List<FileItem> parseRequest = upload.parseRequest(request);
                if (parseRequest != null) {
                    // 遍历
                    for (FileItem item : parseRequest) {
                        // 判断item对象是不是普通表单对象，还是文件上传的对象
                        if (item.isFormField()) {
                            // 获取表单的name属性值
                            String fieldName = item.getFieldName();
                            // 获取表单中输入的值
                            String fieldValue = item.getString("UTF-8");// 对表单中输入的值进行编码

                            System.out.println(fieldName + "=" + fieldValue);

                            params.put(fieldName, fieldValue);
                        } else {
                            // item是一个文件上传的对象
                            // 先获取文件名
                            String fileName = item.getName();
                            // 获取文件内容
                            // InputStream in = item.getInputStream();
                            /*
                             * OutputStream out = new FileOutputStream(new File(path+"/" + fileName)); //拷贝
                             * IOUtils.copy(in, out);
                             */

                            String newFileName = UUID.randomUUID().toString();

                            int lastIndexOfDot = fileName.lastIndexOf(".");
                            if (lastIndexOfDot != -1) {
                                // 有后缀,则要得到后缀
                                String subfix = fileName.substring(lastIndexOfDot);
                                newFileName = newFileName + subfix;
                            }

                            // 把item中的文件流写入到目标位置
                            item.write(new File(uploadFile, newFileName));
                            // 关闭流
                            // in.close();
                            /// out.close();
                            // 应该将缓存区的临时文件清空
                            item.delete();

                            params.put(item.getFieldName(), "true");
                        }
                    }
                }
            } catch (FileUploadException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            // 以前的处理表单的方式
            request.getParameter("name");
        }


        System.out.println("文件上传成功！！！");
        return "success";
    }


    /*
    * 异常处理测试
    * */
    @RequestMapping(path = "/testException")
    public String testException() throws Exception {
        System.out.println("进入FileUploadController.testException()方法了。。。。。");

        try {
            //模拟异常
            int a = 1/0;
        } catch (Exception e) {
            //控制台打印异常
            e.printStackTrace();
            //抛出自定义异常
            throw new ExceptionSchema("查询出错。。。");
        } finally {
        }

        return "success";
    }
    /*
     * 拦截器测试
     * */
    @RequestMapping(path = "/testInterceptor")
    public String testInterceptor() {
        System.out.println("进入FileUploadController.testInterceptor()方法了。。。。。");


        return "success";
    }

}
