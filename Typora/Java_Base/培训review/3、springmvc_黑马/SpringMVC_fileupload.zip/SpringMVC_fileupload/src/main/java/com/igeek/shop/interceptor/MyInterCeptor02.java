package com.igeek.shop.interceptor;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MyInterCeptor02 implements HandlerInterceptor {
    /*
    * 预处理。执行controller之前，return true即放行
    * */
    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o) throws Exception {
        System.out.println("执行了MyInterCeptor02.preHandle()..........");
        //return true;

        //模拟false
        //httpServletRequest.getRequestDispatcher("/WEB-INF/pages/error.jsp").forward(httpServletRequest,httpServletResponse);
        return true;

    }

    /*
    * 在controller执行后，再次拦截。。。  响应jsp执行之前。。。。。
    * 如果这里也有jsp跳转，将不跳转controller对应的success.jsp
    * */
    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {
        System.out.println("执行了MyInterCeptor02.postHandle()..........");
        //httpServletRequest.getRequestDispatcher("/WEB-INF/pages/error.jsp").forward(httpServletRequest,httpServletResponse);


    }

    /*
    *在页面相应之后执行，可以用来关闭连接。
    * */
    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {
        System.out.println("执行了MyInterCeptor02.afterCompletion()..........");

    }
}
